/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-09-29
* Created for: ICS4U
* Daily Assignment:
* Pushes onto stack
*
*******************************************************************************/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ComboLock {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
	        MrCoxallClass aStack = new MrCoxallClass();
	        String anItem;
			
	        InputStreamReader r = new InputStreamReader(System.in);
	        BufferedReader br = new BufferedReader(r);
	        
	        System.out.println("String for stack");
	        try {
	            anItem = br.readLine();
	            aStack.push(anItem);
	            System.out.println(aStack);
	        } catch (IOException e) {
	        	    // TODO Auto-generated catch block
	        	    e.printStackTrace();
	        	}
	    }
		
	}


