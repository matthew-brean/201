import java.util.ArrayList;


public class MrCoxallClass {
    // this class implements a stack object
	
    // the stack will actually be held in a List
    private ArrayList<String> _theStackList = new ArrayList<String>();
	
    public void push(String valueToPutOnStack) {
        // push method adds an item to the stack
		
        _theStackList.add(valueToPutOnStack);
        System.out.println(_theStackList);
    }
}